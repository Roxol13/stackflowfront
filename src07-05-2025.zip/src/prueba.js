import React from 'react';

const prueba = () => {
    return (
        <div style={{ textAlign: 'center', padding: '50px' }}>
            <h1>Bienvenido a la Página de Inicio</h1>
            <button style={{ padding: '10px 20px', fontSize: '16px', backgroundColor: '#908dc7', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
                Explorar
            </button>
        </div>
    );
};

export default prueba;
