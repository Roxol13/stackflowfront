import React from 'react';
import { Modal, Button, Typography } from 'antd';
import { TextField, MenuItem } from '@mui/material';

const EditClientes = ({
    cliente,
    handleInputChange,
    closeModal,
    saveChanges,
    isEditMode,
    errorMessage,
}) => {
    return (
        <Modal
            title={
                <Typography variant="h5" component="h2" sx={{ margin: 0 }}>
                    {isEditMode ? 'Editar Cliente' : 'Crear Cliente'}
                </Typography>
            }
            open={true}
            onCancel={closeModal}
            width="35%"
            footer={[
                <Button key="cancel" onClick={closeModal} style={{ backgroundColor: '#d8243f', color: '#fff' }}>
                    Cancelar
                </Button>,
                <Button key="save" onClick={saveChanges} style={{ backgroundColor: '#28a745', color: '#fff' }}>
                    {isEditMode ? 'Guardar Cambios' : 'Crear Cliente'}
                </Button>,
            ]}
            style={{
                position: 'fixed',
                top: '50px',
                left: '30%',
                right: '30%',
                overflow: 'hidden', // Oculta desbordamiento externo
            }}
        >
            <div
                style={{
                    maxHeight: '60vh', // Altura máxima del contenido
                    overflowY: 'auto', // Permite scroll vertical si el contenido es largo
                    padding: '1rem',
                }}
            >
                <form autoComplete="off" onClick={(e) => e.stopPropagation()}>
                    <div className="mb-3">
                        <TextField
                            fullWidth
                            label="Cédula"
                            name="dni"
                            value={cliente.dni || ''}
                            onChange={handleInputChange}
                            inputProps={{ maxLength: 11 }}
                        />
                    </div>

                    <div className="mb-3">
                        <TextField
                            fullWidth
                            label="Nombre"
                            name="nombre"
                            value={cliente.nombre || ''}
                            onChange={handleInputChange}
                        />
                    </div>

                    <div className="mb-3">
                        <TextField
                            fullWidth
                            type="number"
                            label="Edad"
                            name="edad"
                            value={cliente.edad || ''}
                            onChange={handleInputChange}
                        />
                    </div>

                    <div className="form-outline mb-4">
                        <TextField
                            name="genero"
                            select
                            label="Seleccionar un género"
                            value={cliente.genero || ''}
                            onChange={handleInputChange}
                            fullWidth
                        >
                            <MenuItem value="" disabled>Género</MenuItem>
                            <MenuItem value="Masculino">Masculino</MenuItem>
                            <MenuItem value="Femenino">Femenino</MenuItem>
                            <MenuItem value="Otro">Otro</MenuItem>
                        </TextField>
                    </div>

                    <div className="mb-3">
                        <TextField
                            fullWidth
                            label="Teléfono"
                            name="telefono"
                            value={cliente.telefono || ''}
                            onChange={handleInputChange}
                            inputProps={{ maxLength: 15 }}
                        />
                    </div>

                    <div className="mb-3">
                        <TextField
                            fullWidth
                            label="Dirección"
                            name="direccion"
                            value={cliente.direccion || ''}
                            onChange={handleInputChange}
                        />
                    </div>

                    <div className="mb-3">
                        <TextField
                            fullWidth
                            label="Descripción"
                            name="razon"
                            value={cliente.razon || ''}
                            onChange={handleInputChange}
                        />
                    </div>

                    {errorMessage && (
                        <div className="alert alert-danger mb-3">{errorMessage}</div>
                    )}
                </form>
            </div>
        </Modal>
    );
};

export default EditClientes;
