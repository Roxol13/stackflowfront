import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Modal, Button, Typography } from 'antd';
import { TextField, MenuItem, Select, InputLabel, FormControl } from '@mui/material';

const EditProducto = ({
    producto,
    handleInputChange,
    closeModal,
    saveChanges,
    isEditMode,
    errorMessage,
}) => {
    const [proveedores, setProveedores] = useState([]);

    useEffect(() => {
        const fetchProveedores = async () => {
            const respuesta = await axios.get('http://localhost:8080/api/proveedores');
            setProveedores(respuesta.data);
        };

        fetchProveedores();
    }, []);

    return (
        <Modal
            title={
                <Typography variant="h5" component="h2" sx={{ margin: 0 }}>
                    {isEditMode ? 'Editar Producto' : 'Crear Producto'}
                </Typography>
            }
            open={true}
            onCancel={closeModal}
            width="35%"
            footer={[
                <Button
                    key="cancel"
                    onClick={closeModal}
                    style={{ backgroundColor: '#d8243f', color: '#fff' }}
                >
                    Cancelar
                </Button>,
                <Button
                    key="save"
                    onClick={saveChanges}
                    style={{ backgroundColor: '#28a745', color: '#fff' }}
                >
                    {isEditMode ? 'Guardar Cambios' : 'Crear Producto'}
                </Button>,
            ]}
            style={{
                display: 'block',
                position: 'fixed',
                top: 50,
                left: 30,
                right: 0,
                bottom: 0,
                overflowY: 'auto',
            }}
        >
            <form autoComplete="off">


                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Código"
                        name="codigo"
                        value={producto.codigo || ''}
                        onChange={handleInputChange}
                    />
                </div>

                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Nombre"
                        name="nombre"
                        value={producto.nombre || ''}
                        onChange={handleInputChange}
                    />
                </div>

                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Stock"
                        name="stock"
                        min="0" // esto evita que coloques numero negativos
                        value={producto.stock}
                        onChange={handleInputChange}
                    />
                </div>

                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Precio"
                        name="precio"
                        type="number"
                        min="0" // esto evita que coloques numero negativos
                        value={producto.precio}
                        onChange={handleInputChange}
                    />
                </div>

                <div className="mb-3">
                    <FormControl fullWidth>
                        <InputLabel>Proveedor</InputLabel>
                        <Select
                            name="proveedorId"
                            value={producto.proveedor ? producto.proveedor.id : ''}
                            onChange={handleInputChange}
                            label="Proveedor"
                        >
                            <MenuItem value="">Seleccione un proveedor</MenuItem>
                            {proveedores.map((proveedor) => (
                                <MenuItem key={proveedor.id} value={proveedor.id}>
                                    {proveedor.nombre}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </div>
                {errorMessage && (
                    <div className="alert alert-danger mb-3">{errorMessage}</div>
                )}
            </form>
        </Modal>
    );
};

export default EditProducto;
