import React, { useState } from 'react';
import axios from 'axios';
import {
  Box,
  Button,
  Container,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
  Grid,
  Alert
} from '@mui/material';

function FormularioPrediccion() {
  const [form, setForm] = useState({
    genero: '',
    frecuenciaCompra: '',
    montoPromedio: '',
    ultimaCompra: '',
    descuentoRecibido: '',
    metodoPago: '',
    satisfaccion: ''
  });

  const [resultado, setResultado] = useState(null);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setResultado(null);
    setError(null);

    try {
      const response = await axios.post('http://localhost:8080/api/predecir', form);
      setResultado(response.data);
    } catch (err) {
      setError(err.response?.data || "Error al hacer la predicción.");
    }
  };

  return (
    <Container maxWidth="sm">
      <Box component="form" onSubmit={handleSubmit} sx={{ mt: 5, p: 3, boxShadow: 3, borderRadius: 2 }}>
        <Typography variant="h5" align="center" gutterBottom>
          Predicción de Compra
        </Typography>

        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>Género</InputLabel>
              <Select name="genero" value={form.genero} onChange={handleChange} label="Género">
                <MenuItem value="">Seleccione</MenuItem>
                <MenuItem value="Masculino">Masculino</MenuItem>
                <MenuItem value="Femenino">Femenino</MenuItem>
                <MenuItem value="Otro">Otro</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField label="Frecuencia de Compra" type="number" name="frecuenciaCompra" value={form.frecuenciaCompra} onChange={handleChange} fullWidth />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField label="Monto Promedio" type="number" name="montoPromedio" value={form.montoPromedio} onChange={handleChange} fullWidth />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField label="Última Compra (días)" type="number" name="ultimaCompra" value={form.ultimaCompra} onChange={handleChange} fullWidth />
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>¿Recibió Descuento?</InputLabel>
              <Select name="descuentoRecibido" value={form.descuentoRecibido} onChange={handleChange} label="¿Recibió Descuento?">
                <MenuItem value="">Seleccione</MenuItem>
                <MenuItem value="Si">Sí</MenuItem>
                <MenuItem value="No">No</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>Método de Pago</InputLabel>
              <Select name="metodoPago" value={form.metodoPago} onChange={handleChange} label="Método de Pago">
                <MenuItem value="">Seleccione</MenuItem>
                <MenuItem value="Tarjeta">Tarjeta</MenuItem>
                <MenuItem value="Transferencia">Transferencia</MenuItem>
                <MenuItem value="Efectivo">Efectivo</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField label="Satisfacción (1-10)" type="number" name="satisfaccion" value={form.satisfaccion} onChange={handleChange} fullWidth />
          </Grid>
        </Grid>

        <Box textAlign="center" mt={3}>
          <Button type="submit" variant="contained" color="primary">
            Predecir
          </Button>
        </Box>

        {resultado && <Alert severity="success" sx={{ mt: 2 }}>{resultado}</Alert>}
        {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
      </Box>
    </Container>
  );
}

export default FormularioPrediccion;