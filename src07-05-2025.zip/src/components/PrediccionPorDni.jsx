import React, { useState, useEffect } from 'react';
import {
    Container,
    TextField,
    Button,
    Typography,
    Paper,
    CircularProgress,
    Divider,
    Grid,
    Chip,
    Alert,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow
} from '@mui/material';

import { Box } from '@mui/material';

const PrediccionPorDni = () => {
    const [historialPredicciones, setHistorialPredicciones] = useState([]);
    const [dni, setDni] = useState('');
    const [infoCliente, setInfoCliente] = useState(null);
    const [error, setError] = useState('');
    const [cargando, setCargando] = useState(false);

    // Cargar historial desde localStorage al iniciar
    useEffect(() => {
        const dataGuardada = localStorage.getItem('historialPredicciones');
        if (dataGuardada) {
            setHistorialPredicciones(JSON.parse(dataGuardada));
        }
    }, []);

    const guardarEnHistorial = (cliente) => {
        const nuevoHistorial = [...historialPredicciones, cliente];
        setHistorialPredicciones(nuevoHistorial);
        localStorage.setItem('historialPredicciones', JSON.stringify(nuevoHistorial));
    };

    const handlePredict = async () => {
        if (!dni.trim()) {
            setError('Debes ingresar un DNI');
            setInfoCliente(null);
            return;
        }

        setCargando(true);
        setError('');

        try {
            const response = await fetch(`http://localhost:8080/api/predecir/dni/${dni}`);
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Error al predecir');
            }

            const data = await response.json();
            data.dni = dni; // Añadir DNI al objeto si no viene en la respuesta
            setInfoCliente(data);
            guardarEnHistorial(data);
        } catch (err) {
            setInfoCliente(null);
            setError(err.message);
        } finally {
            setCargando(false);
        }
    };

    const limpiarHistorial = () => {
        localStorage.removeItem('historialPredicciones');
        setHistorialPredicciones([]);
    };

    return (
        <Container maxWidth="md">
            <Paper elevation={3} sx={{ mt: 4, p: 3 }}>
                <Typography variant="h4" align="center" gutterBottom>
                    Predicción por Cédula
                </Typography>

                <Grid container spacing={2} alignItems="center">
                    <Grid item xs={12} sm={9}>
                        <TextField
                            fullWidth
                            label="Ingrese la cédula del cliente"
                            variant="outlined"
                            type="number"
                            value={dni}
                            onChange={(e) => setDni(e.target.value)}
                        />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={handlePredict}
                            disabled={!dni.trim() || cargando}
                            fullWidth
                        >
                            {cargando ? <CircularProgress size={24} /> : 'Predecir'}
                        </Button>
                    </Grid>
                </Grid>

                {error && (
                    <Alert severity="error" sx={{ mt: 3 }}>
                        {error}
                    </Alert>
                )}

                {infoCliente && (
                    <Paper elevation={2} sx={{ mt: 4, p: 3, bgcolor: '#f9f9f9' }}>
                        <Typography variant="h6" gutterBottom>
                            Información del Cliente
                        </Typography>
                        <Divider sx={{ mb: 2 }} />

                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <Typography variant="body1"><strong>Nombre:</strong> {infoCliente.nombre}</Typography>
                                <Typography variant="body2"><strong>DNI:</strong> {dni}</Typography>
                            </Grid>

                            <Grid item xs={6}>
                                <Typography variant="body1">Edad:</Typography>
                                <Chip label={infoCliente.edad} />
                            </Grid>
                            <Grid item xs={6}>
                                <Typography variant="body1">Género:</Typography>
                                <Chip label={infoCliente.genero} />
                            </Grid>

                            <Grid item xs={6}>
                                <Typography variant="body1">Frecuencia de compra:</Typography>
                                <Chip label={infoCliente.frecuenciaCompra} color="primary" />
                            </Grid>
                            <Grid item xs={6}>
                                <Typography variant="body1">Monto promedio:</Typography>
                                <Chip label={`$${infoCliente.montoPromedio.toFixed(2)}`} color="secondary" />
                            </Grid>

                            <Grid item xs={6}>
                                <Typography variant="body1">Días desde última compra:</Typography>
                                <Chip label={`${infoCliente.ultimaCompraDias} días`} />
                            </Grid>
                            <Grid item xs={6}>
                                <Typography variant="body1">Satisfacción promedio:</Typography>
                                <Chip label={`${infoCliente.satisfaccion}/10`} />
                            </Grid>
                        </Grid>

                        <Divider sx={{ my: 2 }} />

                        <Typography variant="h6" align="center">
                            ¿Volverá a comprar?
                            <Box
                                component="span"
                                sx={{
                                    color: infoCliente.resultado === 'Si' ? 'success.main' : 'error.main',
                                    ml: 1,
                                    fontWeight: 'bold'
                                }}
                            >
                                {infoCliente.resultado || 'No determinado'}
                            </Box>
                        </Typography>

                        <Alert severity={infoCliente.resultado === 'Si' ? 'success' : 'warning'} sx={{ mt: 2 }}>
                            <strong>Probabilidad:</strong> {(infoCliente.probabilidad * 100).toFixed(2)}%
                        </Alert>
                    </Paper>
                )}

                {/* Tabla de historial siempre visible */}
                <Paper elevation={2} sx={{ mt: 5, p: 2 }}>
                    <Typography variant="h6" gutterBottom>
                        Historial de predicciones
                    </Typography>
                    <Divider sx={{ mb: 2 }} />

                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>DNI</TableCell>
                                <TableCell>Nombre</TableCell>
                                <TableCell>Edad</TableCell>
                                <TableCell>Género</TableCell>
                                <TableCell>Frecuencia</TableCell>
                                <TableCell>Monto</TableCell>
                                <TableCell>Resultado</TableCell>
                                <TableCell>Probabilidad</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {historialPredicciones.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={8} align="center">
                                        Aún no hay predicciones registradas.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                historialPredicciones.map((item, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{item.dni}</TableCell>
                                        <TableCell>{item.nombre}</TableCell>
                                        <TableCell>{item.edad}</TableCell>
                                        <TableCell>{item.genero}</TableCell>
                                        <TableCell>{item.frecuenciaCompra}</TableCell>
                                        <TableCell>${item.montoPromedio.toFixed(2)}</TableCell>
                                        <TableCell>{item.resultado}</TableCell>
                                        <TableCell>{(item.probabilidad * 100).toFixed(2)}%</TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>

                    {historialPredicciones.length > 0 && (
                        <Box mt={2} display="flex" justifyContent="flex-end">
                            <Button variant="outlined" color="error" onClick={limpiarHistorial}>
                                Limpiar historial
                            </Button>
                        </Box>
                    )}
                </Paper>
            </Paper>
        </Container>
    );
};

export default PrediccionPorDni;
