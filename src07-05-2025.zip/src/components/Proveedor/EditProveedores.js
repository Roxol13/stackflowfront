import React from 'react';
import { Modal, Button, Typography } from 'antd';
import { TextField } from '@mui/material';

const EditProveedores = ({
    proveedor,
    handleInputChange,
    closeModal,
    saveChanges,
    isEditMode,
    errorMessage,
}) => {
    return (
        <Modal
            title={
                <Typography variant="h5" component="h2" sx={{ margin: 0 }}>
                    {isEditMode ? 'Editar Proveedor' : 'Datos del Proveedor'}
                </Typography>
            }
            open={true}
            onCancel={closeModal}
            width="35%"
            footer={[
                <Button
                    key="cancel"
                    onClick={closeModal}
                    style={{ backgroundColor: '#d8243f', color: '#fff' }}
                >
                    Cancelar
                </Button>,
                <Button
                    key="save"
                    onClick={saveChanges}
                    style={{ backgroundColor: '#28a745', color: '#fff' }}
                >
                    {isEditMode ? 'Guardar Cambios' : 'Crear Proveedor'}
                </Button>,
            ]}
            style={{
                display: 'block',
                position: 'fixed',
                top: 50,
                left: 30,
                right: 0,
                bottom: 0,
                overflowY: 'auto',
            }}
        >
            <form autoComplete="off">

                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Cédula"
                        name="ruc"
                        value={proveedor.ruc || ''}
                        onChange={handleInputChange}

                    />
                </div>

                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Nombre"
                        name="nombre"
                        value={proveedor.nombre || ''}
                        onChange={handleInputChange}

                    />
                </div>

                <div className="mb-3">
                    <TextField

                        fullWidth
                        label="Teléfono"
                        name="telefono"
                        value={proveedor.telefono || ''}
                        onChange={handleInputChange}
                        inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}

                    />
                </div>

                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Dirección"
                        name="direccion"
                        value={proveedor.direccion || ''}
                        onChange={handleInputChange}

                    />
                </div>

                <div className="mb-3">
                    <TextField
                        fullWidth
                        label="Descripción"
                        name="razon"
                        value={proveedor.razon || ''}
                        onChange={handleInputChange}

                    />
                </div>
                {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
            </form>
        </Modal>
    );
};

export default EditProveedores;
